<div id="page-wrapper">
    <div class="header">
        <h1 class="page-header">
            Ваша посада не має доступу до даної категорії!
        </h1>
        <ol class="breadcrumb">
            <li><a href="/">Головна сторінка</a></li>
        </ol>
    </div>
    <div id="page-inner">
        <h1></h1>

    </div>
</div>