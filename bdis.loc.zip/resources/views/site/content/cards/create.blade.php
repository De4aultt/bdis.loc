@extends('layouts.site')

@section('css')
    @include('layouts.asset.css')
@endsection

@section('header')
    @include('site.header')
@endsection

@section('content')

<div id="page-wrapper" >
<div class="header">
<h1 class="page-header">
{{ $title }}
</h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('main') }}">Головна</a></li>
        <li><a href="{{ route('picture.index') }}">Картини</a></li>
        <li class="active">Додати картину</li>
    </ol>
</div>

    <div id="page-inner">

<div class="row">
<div class="col-md-12">
<div class="card">

<div class="card-content">

<!-- if there are creation errors, they will show here -->
{{ HTML::ul($errors->all()) }}

{{ Form::open(array('url' => 'picture')) }}

<div class="form-group">
{{ Form::label('name', 'Name') }}
{{ Form::text('name', Input::old('name'), array('class' => 'form-control')) }}
</div>

<div class="form-group">
{{ Form::label('email', 'Email') }}
{{ Form::email('email', Input::old('email'), array('class' => 'form-control')) }}
</div>

<div class="form-group">
{{ Form::label('nerd_level', 'Nerd Level') }}
{{ Form::select('nerd_level', array('0' => 'Select a Level', '1' => 'Sees Sunlight', '2' => 'Foosball Fanatic', '3' => 'Basement Dweller'), Input::old('nerd_level'), array('class' => 'form-control')) }}
</div>

{{ Form::submit('Create the Nerd!', array('class' => 'btn btn-primary')) }}

{{ Form::close() }}
</div>
</div>
</div>
</div>
</div>
</div>

@endsection

@section('js')
    @include('layouts.asset.jsfortable')
@endsection

