<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Managers extends Model
{
    protected $primaryKey = 'Manager_pasport_number';
}
