<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Designers extends Model
{
    protected $primaryKey = 'Designer_pasport_number';
}
