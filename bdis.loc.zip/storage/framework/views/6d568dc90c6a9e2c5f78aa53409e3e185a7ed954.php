<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('layouts.asset.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="header">
            <h1 class="page-header">
                Картина <?php echo e($picture->Picture_id); ?>



                <?php echo e(Form::open([ 'method'  => 'delete', 'route' => [ 'picture.destroy', $picture->Picture_id ] ])); ?>

                <?php echo e(Form::submit('Видалити', ['class' => 'btn btn-small btn-danger right'])); ?>

                <?php echo e(Form::close()); ?>


            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('main')); ?>">Головна</a></li>
                <li><a href="<?php echo e(route('picture.index')); ?>">Картини</a></li>
                <li class="active">Інформація про картину <?php echo e($picture->Picture_id); ?></li>
            </ol>

        </div>
        <div id="page-inner">

            <div class="row">

                <div class="col-md-12">
                    <div class="card">

                        <div class="card-content">
                            <!-- if there are creation errors, they will show here -->
                            <?php echo e(HTML::ul($errors->all())); ?>


                            <?php echo e(Form::model($picture, array('route' => array('picture.update', $picture->Picture_id), 'method' => 'PUT'))); ?>



                            <div class="form-group">
                                <?php echo e(Form::label('File', 'Файл')); ?>

                                <?php echo e(Form::text('File', null, array('class' => 'form-control'))); ?>

                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('Style', 'Стиль')); ?>

                                <?php echo e(Form::select('Style', [ 'Не визначено' =>'Оберіть стиль', 'Колаж' => 'Колаж', 'Поп-арт' => 'Поп-арт','Портрет' => 'Портрет'], Input::old('Style'), array('class' => 'form-control'))); ?>

                            </div>

                            <div class="form-group">
                                <?php echo e(Form::label('Price', 'Ціна')); ?>

                                <?php echo e(Form::number('Price', null , array('class' => 'form-control'))); ?>

                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('Designer_pasport_number', 'Номер дизайнера')); ?>


                                <?php echo e(Form::select('Designer_pasport_number', $designers , Input::old('Designer_pasport_number'), array('class' => 'form-control'))); ?>

                            </div>




                            <?php echo e(Form::submit('Редагувати', array('class' => 'btn btn-primary'))); ?>


                            <?php echo e(Form::close()); ?>








                        </div>
                    </div>

                    <footer><p>All right reserved. Template by: <a href="https://webthemez.com/admin-template/">WebThemez.com</a></p></footer>
                </div>
                <!-- /. PAGE INNER  -->
            </div>
            <!-- /. PAGE WRAPPER  -->
        </div>
    </div>
    <!-- /. WRAPPER  -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('layouts.asset.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>