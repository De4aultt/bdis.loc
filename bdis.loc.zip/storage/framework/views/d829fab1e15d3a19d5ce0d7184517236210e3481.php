<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('layouts.asset.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="header">
            <h1 class="page-header">
                Клієнт <?php echo e($client->Client_Number); ?>

                <br>

                <?php echo e(Form::open([ 'method'  => 'delete', 'route' => [ 'client.destroy', $client->Client_Number] ])); ?>

                <?php echo e(Form::submit('Видалити', ['class' => 'btn btn-small btn-danger right'])); ?>

                <?php echo e(Form::close()); ?>

                <a href="<?php echo e(URL::to('client/' . $client->Client_Number. '/edit')); ?>">
                    <div class="btn btn-small btn-info right" >Редагувати</div></a>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('main')); ?>">Головна</a></li>
                <li><a href="<?php echo e(route('client.index')); ?>">Клієнти</a></li>
                <li class="active">Інформація про клієнта <?php echo e($client->Client_Number); ?></li>
            </ol>

        </div>
        <div id="page-inner">

            <div class="row">

                <div class="col-md-12">
                    <div class="card">

                        <div class="card-content">
                            <p>
                                <strong>Номер паспорта:</strong> <?php echo e($client->Client_Number); ?><br>
                                <strong>Прізвище:</strong> <?php echo e($client->Surname); ?><br>
                                <strong>Ім'я:</strong> <?php echo e($client->Name); ?><br>
                                <strong>По батькові:</strong> <?php echo e($client->Father_name); ?><br>
                                <strong>Дата народження:</strong> <?php echo e($client->Birthday); ?><br>
                                <strong>Стать:</strong> <?php echo e($client->Gender); ?><br>
                                <strong>Номер менеджера:</strong> <a href="<?php echo e(URL::to('manager/' . $client->Manager_Pasport_Number)); ?>"> <?php echo e($client->Manager_Pasport_Number); ?></a><br>
                                <strong>Запис створено:</strong> <?php echo e($client->created_at); ?><br>
                                <strong>Останнє оновлення:</strong> <?php echo e($client->updated_at); ?><br>
                            </p>
                            <div class="clearBoth"><br/></div>

                        </div>
                    </div>

                    <footer><p>All right reserved. Template by: <a href="https://webthemez.com/admin-template/">WebThemez.com</a></p></footer>
                </div>
                <!-- /. PAGE INNER  -->
            </div>
            <!-- /. PAGE WRAPPER  -->
        </div>
    </div>
        <!-- /. WRAPPER  -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('layouts.asset.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>