<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($title); ?></title>

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<?php echo $__env->yieldContent('css'); ?>
</head>

<body>
<div id="wrapper">
<?php echo $__env->yieldContent('header'); ?>
<?php echo $__env->yieldContent('content'); ?>
</div>
<?php echo $__env->yieldContent('js'); ?>


</body>

</html>