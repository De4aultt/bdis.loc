<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('layouts.asset.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="header">
            <h1 class="page-header">
                Менеджер <?php echo e($manager->Manager_pasport_number); ?>



                <?php echo e(Form::open([ 'method'  => 'delete', 'route' => [ 'manager.destroy', $manager->Manager_pasport_number ] ])); ?>

                <?php echo e(Form::submit('Видалити', ['class' => 'btn btn-small btn-danger right'])); ?>

                <?php echo e(Form::close()); ?>


            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('main')); ?>">Головна</a></li>
                <li><a href="<?php echo e(route('manager.index')); ?>">Менеджери</a></li>
                <li class="active">Редагувати менеджера <?php echo e($manager->Manager_pasport_number); ?></li>
            </ol>

        </div>
        <div id="page-inner">

            <div class="row">

                <div class="col-md-12">
                    <div class="card">

                        <div class="card-content">
                            <!-- if there are creation errors, they will show here -->
                            <?php echo e(HTML::ul($errors->all())); ?>


                            <?php echo e(Form::model($manager, array('route' => array('manager.update', $manager->Manager_pasport_number), 'method' => 'PUT'))); ?>



                            <div class="form-group">
                                <?php echo e(Form::label('Manager_pasport_number', 'Номер паспорта')); ?>

                                <?php echo e(Form::text('Manager_pasport_number', null, array('class' => 'form-control'))); ?>

                            </div>

                            <div class="form-group">
                                <?php echo e(Form::label('Surname', 'Прізвище')); ?>

                                <?php echo e(Form::text('Surname', null, array('class' => 'form-control'))); ?>

                            </div>

                            <div class="form-group">
                                <?php echo e(Form::label('Name', 'Ім\'я')); ?>

                                <?php echo e(Form::text('Name', null, array('class' => 'form-control'))); ?>

                            </div>

                            <div class="form-group">
                                <?php echo e(Form::label('Father_name', 'По батькові')); ?>

                                <?php echo e(Form::text('Father_name', null, array('class' => 'form-control'))); ?>

                            </div>

                            <div class="form-group">
                                <?php echo e(Form::label('Birthday', 'Дата народження')); ?>

                                <?php echo e(Form::date('Birthday', null, array('class' => 'form-control'))); ?>

                            </div>

                            <div class="form-group">
                                <?php echo e(Form::label('Salary', 'Зарплата (грн.)')); ?>

                                <?php echo e(Form::text('Salary', null, array('class' => 'form-control'))); ?>

                            </div>



                            <?php echo e(Form::submit('Редагувати', array('class' => 'btn btn-primary'))); ?>


                            <?php echo e(Form::close()); ?>








                        </div>
                    </div>

                    <footer><p>All right reserved. Template by: <a href="https://webthemez.com/admin-template/">WebThemez.com</a></p></footer>
                </div>
                <!-- /. PAGE INNER  -->
            </div>
            <!-- /. PAGE WRAPPER  -->
        </div>
    </div>
    <!-- /. WRAPPER  -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('layouts.asset.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>