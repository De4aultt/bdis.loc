<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('layouts.asset.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="header">
            <h1 class="page-header">
                Телефон менеджера <?php echo e($phone->Manager_pasport_number); ?>

                <br>

                <?php echo e(Form::open([ 'method'  => 'delete', 'route' => [ 'phone.destroy', $phone->Phone_number_id] ])); ?>

                <?php echo e(Form::submit('Видалити', ['class' => 'btn btn-small btn-danger right'])); ?>

                <?php echo e(Form::close()); ?>

                <a href="<?php echo e(URL::to('phone/' . $phone->Phone_number_id. '/edit')); ?>">
                    <div class="btn btn-small btn-info right" >Редагувати</div></a>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('main')); ?>">Головна</a></li>
                <li><a href="<?php echo e(route('phone.index')); ?>">Телефон</a></li>
                <li class="active">Інформація про телефон менеджера <?php echo e($phone->Manager_pasport_number); ?></li>
            </ol>

        </div>
        <div id="page-inner">

            <div class="row">

                <div class="col-md-12">
                    <div class="card">

                        <div class="card-content">
                            <p>
                                <strong>Номер манеджера:</strong> <a href="<?php echo e(URL::to('manager/' . $phone->Manager_pasport_number)); ?>"><?php echo e($phone->Manager_pasport_number); ?></a><br>
                                <strong>Мобільний:</strong> <?php echo e($phone->Mobile); ?><br>
                                <strong>Домашній:</strong> <?php echo e($phone->Home); ?><br>
                                <strong>Запис створено:</strong> <?php echo e($phone->created_at); ?><br>
                                <strong>Останнє оновлення:</strong> <?php echo e($phone->updated_at); ?><br>
                            </p>
                            <div class="clearBoth"><br/></div>

                        </div>
                    </div>

                    <footer><p>All right reserved. Template by: <a href="https://webthemez.com/admin-template/">WebThemez.com</a></p></footer>
                </div>
                <!-- /. PAGE INNER  -->
            </div>
            <!-- /. PAGE WRAPPER  -->
        </div>
    </div>
        <!-- /. WRAPPER  -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('layouts.asset.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>