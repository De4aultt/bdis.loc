
<div id="page-wrapper" >
    <div class="header">
        <h1 class="page-header">
            <?php echo e($title); ?>

        </h1>
        <ol class="breadcrumb">
            <li><a href="#">Home</a></li>
            <li><a href="#">Tables</a></li>
            <li class="active">Data</li>
        </ol>

    </div>

    <div id="page-inner">

        <div class="row">
            <div class="col-md-12">
                <!-- Advanced Tables -->
                <div class="card">

                    <div class="card-content">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover" id="dataTables-table">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Дата написання</th>
                                    <th>Файл</th>
                                    <th>Стиль</th>
                                    <th>Ціна (грн.)</th>
                                    <th>Номер дизайнера</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="gradeA">
                                    <td><?php echo e($picture->Picture_id); ?></td>
                                    <td><?php echo e($picture->Date_made); ?></td>
                                    <td><a href="<?php echo e($picture->File); ?>">відкрити</a></td>
                                    <td><?php echo e($picture->Style); ?></td>
                                    <td><?php echo e($picture->Price); ?></td>
                                    <td><?php echo e($picture->Designer_pasport_number); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
                <!--End Advanced Tables -->
            </div>
        </div>



        <footer><p>All right reserved. Template by: <a href="https://webthemez.com/admin-template/">WebThemez.com</a></p></footer>
    </div>
    <!-- /. PAGE INNER  -->
</div>
