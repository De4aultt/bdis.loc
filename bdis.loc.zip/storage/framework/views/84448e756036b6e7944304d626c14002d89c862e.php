<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('layouts.asset.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper" >
<div class="header">
<h1 class="page-header">
<?php echo e($title); ?>

</h1>
</div>
<nav class="navbar navbar-inverse">
<div class="navbar-header">
<a class="navbar-brand" href="<?php echo e(URL::to('picture')); ?>">Nerd Alert</a>
</div>
<ul class="nav navbar-nav">
<li><a href="<?php echo e(URL::to('picture')); ?>">View All picture</a></li>
<li><a href="<?php echo e(URL::to('picture/create')); ?>">Create a Nerd</a>
</ul>
</nav>
<div id="page-inner">

<div class="row">
<div class="col-md-12">
<div class="card">

<div class="card-content">
<h1>Create a Nerd</h1>

<!-- if there are creation errors, they will show here -->
<?php echo e(HTML::ul($errors->all())); ?>


<?php echo e(Form::open(array('url' => 'picture'))); ?>


<div class="form-group">
<?php echo e(Form::label('name', 'Name')); ?>

<?php echo e(Form::text('name', Input::old('name'), array('class' => 'form-control'))); ?>

</div>

<div class="form-group">
<?php echo e(Form::label('email', 'Email')); ?>

<?php echo e(Form::email('email', Input::old('email'), array('class' => 'form-control'))); ?>

</div>

<div class="form-group">
<?php echo e(Form::label('nerd_level', 'Nerd Level')); ?>

<?php echo e(Form::select('nerd_level', array('0' => 'Select a Level', '1' => 'Sees Sunlight', '2' => 'Foosball Fanatic', '3' => 'Basement Dweller'), Input::old('nerd_level'), array('class' => 'form-control'))); ?>

</div>

<?php echo e(Form::submit('Create the Nerd!', array('class' => 'btn btn-primary'))); ?>


<?php echo e(Form::close()); ?>

</div>
</div>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('layouts.asset.jsfortable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>