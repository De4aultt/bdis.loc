<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('layouts.asset.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper" >
    <div class="header">
        <h1 class="page-header">
        <?php echo e($title); ?>

        </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('main')); ?>">Головна</a></li>
                <li><a href="<?php echo e(route('picture.index')); ?>">Картини</a></li>
                <li class="active">Додати картину</li>
            </ol>
        </div>

            <div id="page-inner">

        <div class="row">
            <div class="col-md-12">
                <div class="card">

                    <div class="card-content">

                        <!-- if there are creation errors, they will show here -->
                            <?php echo e(HTML::ul($errors->all())); ?>


                            <?php echo e(Form::open(array('url' => 'picture'))); ?>


                            <div class="form-group">
                                <?php echo e(Form::label('Date_made', 'Дата виготовлення')); ?>

                                <?php echo e(Form::date('Date_made', Input::old('Date_made'), array('class' => 'form-control'))); ?>

                            </div>


                            <div class="input-field col s12">
                                <?php echo e(Form::label('File', 'Файл')); ?>

                                <?php echo e(Form::text('File', Input::old('File'), array('class' => 'form-control'))); ?>

                            </div>
                        <div class="form-group">
                            <?php echo e(Form::label('Style', 'Стиль')); ?>

                            <?php echo e(Form::select('Style', [ 'Не визначено' =>'Оберіть стиль', 'Колаж' => 'Колаж', 'Поп-арт' => 'Поп-арт','Портрет' => 'Портрет'], Input::old('Style'), array('class' => 'form-control'))); ?>

                        </div>

                        <div class="input-field col s12">
                            <?php echo e(Form::label('Price', 'Ціна')); ?>

                            <?php echo e(Form::number('Price', Input::old('Price'), array('class' => 'form-control'))); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('Designer_pasport_number', 'Номер дизайнера')); ?>


                            <?php echo e(Form::select('Designer_pasport_number', $designers , Input::old('Designer_pasport_number'), array('class' => 'form-control'))); ?>

                        </div>



                            <?php echo e(Form::submit('Додати', array('class' => 'btn btn-primary'))); ?>


                            <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('layouts.asset.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>