<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('layouts.asset.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper" >
    <div class="header">
        <h1 class="page-header">
        <?php echo e($title); ?>

        </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('main')); ?>">Головна</a></li>
                <li class="active">Змінити пароль</li>
            </ol>
        </div>

            <div id="page-inner">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                <div class="card-content">
                    <!-- if there are creation errors, they will show here -->
                    <?php echo e(HTML::ul($errors->all())); ?>


                    <?php echo e(Form::model($user, array('route' => array('change'), 'method' => 'PUT'))); ?>


                    <div class="input-field col s12">
                        <?php echo e(Form::label('password', 'Новий пароль')); ?>

                        <?php echo e(Form::password('password', null, array('class' => 'form-control'))); ?>

                    </div>



                    <?php echo e(Form::submit('Зберегти', array('class' => 'btn btn-primary'))); ?>


                    <?php echo e(Form::close()); ?>



                    </div>
                </div>

            </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('layouts.asset.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>