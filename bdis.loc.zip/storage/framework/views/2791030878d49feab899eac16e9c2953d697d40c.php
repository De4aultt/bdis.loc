
<div id="page-wrapper" >
    <div class="header">
        <h1 class="page-header">
            <?php echo e($title); ?>

        </h1>

        <div class="breadcrumb">
            <li><a  href="<?php echo e(URL::to('picture/create')); ?>">Додати картину</a>
        </div>


    </div>

    <div id="page-inner">

        <div class="row">
            <div class="col-md-12">
                <!-- Advanced Tables -->
                <div class="card">

                    <div class="card-content">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover" id="dataTables-table">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Дата виготовлення</th>
                                    <th>Зображення</th>
                                    <th>Стиль</th>
                                    <th>Ціна (грн.)</th>
                                    <th>Номер дизайнера</th>
                                    <th>Управління</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="gradeA">
                                    <td><?php echo e($picture->Picture_id); ?></td>
                                    <td><?php echo e($picture->Date_made); ?></td>
                                    <td><a href="<?php echo e($picture->File); ?>">відкрити</a></td>
                                    <td><?php echo e($picture->Style); ?></td>
                                    <td><?php echo e($picture->Price); ?></td>
                                    <td><a href="<?php echo e(URL::to('designer/' . $picture->Designer_pasport_number)); ?>"><?php echo e($picture->Designer_pasport_number); ?></a></td>
                                    <td>
                                        <!-- delete the nerd (uses the destroy method DESTROY /nerds/{id} -->
                                        <!-- we will add this later since its a little more complicated than the other two buttons -->
                                        <!-- show the nerd (uses the show method found at GET /nerds/{id} -->
                                        <a class="btn btn-small btn-success" href="<?php echo e(URL::to('picture/' . $picture->Picture_id)); ?>"><i class="fa fa-eye"></i></a>
                                        <!-- edit this nerd (uses the edit method found at GET /nerds/{id}/edit -->
                                        <a class="btn btn-small btn-info" href="<?php echo e(URL::to('picture/' . $picture->Picture_id . '/edit')); ?>"><i class="fa fa-edit"></i></a>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
                <!--End Advanced Tables -->
            </div>
        </div>



        <footer><p>All right reserved. Template by: <a href="https://webthemez.com/admin-template/">WebThemez.com</a></p></footer>
    </div>
    <!-- /. PAGE INNER  -->
</div>
