<link rel="stylesheet" href="<?php echo e(url("assets/materialize/css/materialize.min.css")); ?>" media="screen,projection" />
<!-- Bootstrap Styles-->
<link href="<?php echo e(url('assets/css/bootstrap.css')); ?>" rel="stylesheet" />
<!-- FontAwesome Styles-->
<link href="<?php echo e(url('assets/css/font-awesome.css')); ?>" rel="stylesheet" />
<!-- Morris Chart Styles-->
<link href="<?php echo e(url('assets/js/morris/morris-0.4.3.min.css')); ?>" rel="stylesheet" />
<!-- Custom Styles-->
<link href="<?php echo e(url('assets/css/custom-styles.css')); ?>" rel="stylesheet" />
<!-- Google Fonts-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="<?php echo e(url('assets/js/Lightweight-Chart/cssCharts.css')); ?>">