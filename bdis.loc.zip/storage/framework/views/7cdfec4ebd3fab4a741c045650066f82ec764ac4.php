    <nav class="navbar navbar-default top-navbar" role="navigation">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle waves-effect waves-dark" data-toggle="collapse" data-target=".sidebar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand waves-effect waves-dark" href="<?php echo e(route('main')); ?>"><i class="large material-icons">insert_chart</i> <strong>BDIS</strong></a>

            <div id="sideNav" href=""><i class="material-icons dp48">toc</i></div>
        </div>

        <ul class="nav navbar-top-links navbar-right">
                <li><a class="dropdown-button waves-effect waves-dark" href="#!" data-activates="dropdown1"><i class="fa fa-user fa-fw"></i> <b><?php echo e(Illuminate\Support\Facades\Auth::user()->surname); ?> <?php echo e(Illuminate\Support\Facades\Auth::user()->name); ?></b> <i class="material-icons right">arrow_drop_down</i></a></li>
        </ul>
    </nav>
    <!-- Dropdown Structure -->
    <ul id="dropdown1" class="dropdown-content">
        <?php if( Illuminate\Support\Facades\Auth::user()->position == 'Менеджер'): ?>
        <li><a href="<?php echo e(URL::to('manager/' . Illuminate\Support\Facades\Auth::user()->passport_number)); ?>"><i class="fa fa-file-text fa-fw"></i> Мій профіль</a>
        </li>
        <?php else: ?>
        <li><a href="<?php echo e(URL::to('designer/' . Illuminate\Support\Facades\Auth::user()->passport_number)); ?>"><i class="fa fa-file-text fa-fw"></i> Мій профіль</a>
        </li>
        <?php endif; ?>
            <li><a href="<?php echo e(route('password')); ?>"><i class="fa fa-key fa-fw"></i> Змінити пароль</a>
            </li>
        <li>
            <a href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                <i class="fa fa-sign-out fa-fw"></i> Вийти
            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo e(csrf_field()); ?>

            </form>
        </li>
    </ul>

    <!--/. NAV TOP  -->
    <nav class="navbar-default navbar-side" role="navigation">
        <ul class="sidebar-collapse">
            <ul class="nav" id="main-menu">

                <li>
                    <a class="waves-effect waves-dark" href="<?php echo e(route('main')); ?>"><i class="fa fa-home"></i> Головна</a>
                </li>
                
                    
                
                
                    
                
                
                    
                
                <li>
                    <a href="#" class="waves-effect waves-dark"><i class="fa fa-table"></i>Категорії<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="<?php echo e(route('designer.index')); ?>">Дизайнери</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('picture.index')); ?>">Картини</a>
                        </li>
                        <?php if( Illuminate\Support\Facades\Auth::user()->position == 'Менеджер'): ?>
                        <li>
                            <a href="<?php echo e(route('order.index')); ?>">Замовлення</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('chek.index')); ?>">Чеки</a>
                        </li>
                            <li>
                                <a href="<?php echo e(route('client.index')); ?>">Клієнти</a>
                            </li>
                        <li>
                            <a href="<?php echo e(route('manager.index')); ?>">Менеджери</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('phone.index')); ?>">Номери телефонів</a>
                        </li>

                    </ul>

                </li>
                <li>
                    <a href="#" class="waves-effect waves-dark"><i class="fa fa-users"></i>Реєстація юзерів<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="<?php echo e(route('designer.create')); ?>">Додати дизайнера</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('manager.create')); ?>">Додати менеджера</a>
                        </li>
                    </ul>
                </li>
            </ul>
    <?php else: ?>
        </ul>
                </li>
            </ul>
            <?php endif; ?>

        </div>

    </nav>
    <!-- /. NAV SIDE  -->
