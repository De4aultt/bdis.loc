<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('layouts.asset.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="header">
            <h1 class="page-header">
                Дизайнер <?php echo e($designer->Designer_pasport_number); ?>

                <br>

                <?php echo e(Form::open([ 'method'  => 'delete', 'route' => [ 'designer.destroy', $designer->Designer_pasport_number] ])); ?>

                <?php echo e(Form::submit('Видалити', ['class' => 'btn btn-small btn-danger right'])); ?>

                <?php echo e(Form::close()); ?>

                <a href="<?php echo e(URL::to('designer/' . $designer->Designer_pasport_number. '/edit')); ?>">
                    <div class="btn btn-small btn-info right" >Редагувати</div></a>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('main')); ?>">Головна</a></li>
                <li><a href="<?php echo e(route('designer.index')); ?>">Дизайнери</a></li>
                <li class="active">Інформація про дизайнера <?php echo e($designer->Designer_pasport_number); ?></li>
            </ol>

        </div>
        <div id="page-inner">

            <div class="row">

                <div class="col-md-12">
                    <div class="card">

                        <div class="card-content">
                            <p>
                                <strong>Номер паспорта:</strong> <?php echo e($designer->Designer_pasport_number); ?><br>
                                <strong>Прізвище:</strong> <?php echo e($designer->Surname); ?><br>
                                <strong>Ім'я:</strong> <?php echo e($designer->Name); ?><br>
                                <strong>По батькові:</strong> <?php echo e($designer->Father_name); ?><br>
                                <strong>Зарплат (грн.):</strong> <?php echo e($designer->Salary); ?><br>
                                <strong>Стать:</strong> <?php echo e($designer->Gender); ?><br>
                                <strong>Email:</strong> <?php echo e($designer->Email); ?><br>
                                <strong>Запис створено:</strong> <?php echo e($designer->created_at); ?><br>
                                <strong>Останнє оновлення:</strong> <?php echo e($designer->updated_at); ?><br>
                            </p>
                            <div class="clearBoth"><br/></div>

                        </div>
                    </div>

                    <footer><p>All right reserved. Template by: <a href="https://webthemez.com/admin-template/">WebThemez.com</a></p></footer>
                </div>
                <!-- /. PAGE INNER  -->
            </div>
            <!-- /. PAGE WRAPPER  -->
        </div>
    </div>
        <!-- /. WRAPPER  -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('layouts.asset.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>