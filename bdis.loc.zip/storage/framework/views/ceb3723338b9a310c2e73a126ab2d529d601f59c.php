<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('layouts.asset.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper" >
    <div class="header">
        <h1 class="page-header">
        <?php echo e($title); ?>

        </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('main')); ?>">Головна</a></li>
                <li><a href="<?php echo e(route('chek.index')); ?>">Чеки</a></li>
                <li class="active">Додати чек</li>
            </ol>
        </div>

            <div id="page-inner">

        <div class="row">
            <div class="col-md-12">
                <div class="card">

                    <div class="card-content">

                        <!-- if there are creation errors, they will show here -->
                            <?php echo e(HTML::ul($errors->all())); ?>


                            <?php echo e(Form::open(array('url' => 'chek'))); ?>



                        <div class="input-field col s12">
                            <?php echo e(Form::label('Count', 'Кількість')); ?>

                            <?php echo e(Form::number('Count', Input::old('Count'), array('class' => 'form-control'))); ?>

                        </div>

                        <div class="input-field col s12">
                            <?php echo e(Form::label('Total_price', 'Загальна ціна')); ?>

                            <?php echo e(Form::number('Total_price', Input::old('Total_price'), array('class' => 'form-control'))); ?>

                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('Picture_number', 'Номер картини')); ?>

                            <?php echo e(Form::select('Picture_number', $pictures , Input::old('Picture_number'), array('class' => 'form-control'))); ?>

                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('Order_number', 'Номер замовлення')); ?>

                            <?php echo e(Form::select('Order_number', $orders , Input::old('Order_number'), array('class' => 'form-control'))); ?>

                        </div>

                            <?php echo e(Form::submit('Додати', array('class' => 'btn btn-primary'))); ?>


                            <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('layouts.asset.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>