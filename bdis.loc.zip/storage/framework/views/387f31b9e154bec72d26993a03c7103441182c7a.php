<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('layouts.asset.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="header">
            <h1 class="page-header">
                Замовлення <?php echo e($order->Order_id); ?>



                <?php echo e(Form::open([ 'method'  => 'delete', 'route' => [ 'order.destroy', $order->Order_id ] ])); ?>

                <?php echo e(Form::submit('Видалити', ['class' => 'btn btn-small btn-danger right'])); ?>

                <?php echo e(Form::close()); ?>


            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('main')); ?>">Головна</a></li>
                <li><a href="<?php echo e(route('order.index')); ?>">Замовлення</a></li>
                <li class="active">Редагувати замовлення <?php echo e($order->Order_id); ?></li>
            </ol>

        </div>
        <div id="page-inner">

            <div class="row">

                <div class="col-md-12">
                    <div class="card">

                        <div class="card-content">
                            <!-- if there are creation errors, they will show here -->
                            <?php echo e(HTML::ul($errors->all())); ?>


                            <?php echo e(Form::model($order, array('route' => array('order.update', $order->Order_id), 'method' => 'PUT'))); ?>



                            <div class="form-group">
                                <?php echo e(Form::label('Town', 'Місто')); ?>

                                <?php echo e(Form::text('Town', null, array('class' => 'form-control'))); ?>

                            </div>

                            <div class="form-group">
                                <?php echo e(Form::label('Street', 'Вулиця')); ?>

                                <?php echo e(Form::text('Street', null, array('class' => 'form-control'))); ?>

                            </div>

                            <div class="form-group">
                                <?php echo e(Form::label('House', 'Будинок')); ?>

                                <?php echo e(Form::text('House', null, array('class' => 'form-control'))); ?>

                            </div>


                            <div class="form-group">
                                <?php echo e(Form::label('Manager_pasport_number', 'Номер менеджера')); ?>


                                <?php echo e(Form::select('Manager_pasport_number', $managers , Input::old('Manager_pasport_number'), array('class' => 'form-control'))); ?>

                            </div>


                            <?php echo e(Form::submit('Редагувати', array('class' => 'btn btn-primary'))); ?>


                            <?php echo e(Form::close()); ?>








                        </div>
                    </div>

                    <footer><p>All right reserved. Template by: <a href="https://webthemez.com/admin-template/">WebThemez.com</a></p></footer>
                </div>
                <!-- /. PAGE INNER  -->
            </div>
            <!-- /. PAGE WRAPPER  -->
        </div>
    </div>
    <!-- /. WRAPPER  -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('layouts.asset.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>