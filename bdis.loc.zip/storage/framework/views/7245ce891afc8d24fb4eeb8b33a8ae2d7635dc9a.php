<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('layouts.asset.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="header">
            <h1 class="page-header">
                Чек <?php echo e($chek->id); ?>

                <br>

                <?php echo e(Form::open([ 'method'  => 'delete', 'route' => [ 'chek.destroy', $chek->id] ])); ?>

                <?php echo e(Form::submit('Видалити', ['class' => 'btn btn-small btn-danger right'])); ?>

                <?php echo e(Form::close()); ?>

                <a href="<?php echo e(URL::to('chek/' . $chek->id. '/edit')); ?>">
                    <div class="btn btn-small btn-info right" >Редагувати</div></a>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('main')); ?>">Головна</a></li>
                <li><a href="<?php echo e(route('chek.index')); ?>">Чеки</a></li>
                <li class="active">Інформація про чек <?php echo e($chek->id); ?></li>
            </ol>

        </div>
        <div id="page-inner">

            <div class="row">

                <div class="col-md-12">
                    <div class="card">

                        <div class="card-content">
                            <p>
                                <strong>Кількість:</strong> <?php echo e($chek->Count); ?><br>
                                <strong>Загальна:</strong> <?php echo e($chek->Total_price); ?><br>
                                <strong>Номер картини:</strong> <a href="<?php echo e(URL::to('picture/' . $chek->Picture_number)); ?>"><?php echo e($chek->Picture_number); ?></a><br>
                                <strong>Номер замовлення:</strong> <a href="<?php echo e(URL::to('order/' . $chek->Order_number)); ?>"><?php echo e($chek->Order_number); ?></a><br>
                                <strong>Запис створено:</strong> <?php echo e($chek->created_at); ?><br>
                                <strong>Останнє оновлення:</strong> <?php echo e($chek->updated_at); ?><br>
                            </p>
                            <div class="clearBoth"><br/></div>

                        </div>
                    </div>

                    <footer><p>All right reserved. Template by: <a href="https://webthemez.com/admin-template/">WebThemez.com</a></p></footer>
                </div>
                <!-- /. PAGE INNER  -->
            </div>
            <!-- /. PAGE WRAPPER  -->
        </div>
    </div>
        <!-- /. WRAPPER  -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('layouts.asset.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>