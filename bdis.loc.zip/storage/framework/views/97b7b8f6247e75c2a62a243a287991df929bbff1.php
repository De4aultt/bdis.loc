<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('layouts.asset.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="header">
            <h1 class="page-header">
                Картина <?php echo e($picture->Picture_id); ?>

                <br>

                <?php echo e(Form::open([ 'method'  => 'delete', 'route' => [ 'picture.destroy', $picture->Picture_id ] ])); ?>

                <?php echo e(Form::submit('Видалити', ['class' => 'btn btn-small btn-danger right'])); ?>

                <?php echo e(Form::close()); ?>

                <a href="<?php echo e(URL::to('picture/' . $picture->Picture_id . '/edit')); ?>">
                    <div class="btn btn-small btn-info right" >Редагувати</div></a>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('main')); ?>">Головна</a></li>
                <li><a href="<?php echo e(route('picture.index')); ?>">Картини</a></li>
                <li class="active">Інформація про картину <?php echo e($picture->Picture_id); ?></li>
            </ol>

        </div>
        <div id="page-inner">

            <div class="row">

                <div class="col-md-12">
                    <div class="card">

                        <div class="card-content">
                            <p>
                                <strong>Дата виготовлення:</strong> <?php echo e($picture->Date_made); ?><br>
                                <strong>Файл:</strong> <a href="<?php echo e($picture->File); ?>">Відкрити</a><br>
                                <strong>Стиль:</strong> <?php echo e($picture->Style); ?><br>
                                <strong>Ціна (грн.):</strong> <?php echo e($picture->Price); ?><br>
                                <strong>Номер дизайнера:</strong> <a href="<?php echo e(URL::to('designer/' . $picture->Designer_pasport_number)); ?>"><?php echo e($picture->Designer_pasport_number); ?></a><br>
                                <strong>Запис створено:</strong> <?php echo e($picture->created_at); ?><br>
                                <strong>Останнє оновлення:</strong> <?php echo e($picture->updated_at); ?><br>
                            </p>
                            <div class="clearBoth"><br/></div>

                        </div>
                    </div>

                    <footer><p>All right reserved. Template by: <a href="https://webthemez.com/admin-template/">WebThemez.com</a></p></footer>
                </div>
                <!-- /. PAGE INNER  -->
            </div>
            <!-- /. PAGE WRAPPER  -->
        </div>
    </div>
        <!-- /. WRAPPER  -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('layouts.asset.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>