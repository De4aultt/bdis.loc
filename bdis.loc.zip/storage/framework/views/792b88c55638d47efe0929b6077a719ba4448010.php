<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('layouts.asset.css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="header">
            <h1 class="page-header">
                Менеджер <?php echo e($manager->Manager_pasport_number); ?>

                <br>

                <?php echo e(Form::open([ 'method'  => 'delete', 'route' => [ 'manager.destroy', $manager->Manager_pasport_number ] ])); ?>

                <?php echo e(Form::submit('Видалити', ['class' => 'btn btn-small btn-danger right'])); ?>

                <?php echo e(Form::close()); ?>

                <a href="<?php echo e(URL::to('manager/' . $manager->Manager_pasport_number . '/edit')); ?>">
                    <div class="btn btn-small btn-info right" >Редагувати</div></a>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('main')); ?>">Головна</a></li>
                <li><a href="<?php echo e(route('manager.index')); ?>">Менеджери</a></li>
                <li class="active">Інформація про менеджера <?php echo e($manager->Manager_pasport_number); ?></li>
            </ol>

        </div>
        <div id="page-inner">

            <div class="row">

                <div class="col-md-12">
                    <div class="card">

                        <div class="card-content">
                            <p>
                                <strong>Номер паспорту:</strong> <?php echo e($manager->Manager_pasport_number); ?><br>
                                <strong>Прізвище:</strong> <?php echo e($manager->Surname); ?><br>
                                <strong>Ім'я:</strong> <?php echo e($manager->Name); ?><br>
                                <strong>По батькові:</strong> <?php echo e($manager->Father_name); ?><br>
                                <strong>Дата народження:</strong> <?php echo e($manager->Birthday); ?><br>
                                <strong>Зарплата (грн.):</strong> <?php echo e($manager->Salary); ?><br>
                                <strong>Запис створено:</strong> <?php echo e($manager->created_at); ?><br>
                                <strong>Останнє оновлення:</strong> <?php echo e($manager->updated_at); ?><br>
                            </p>
                            <div class="clearBoth"><br/></div>

                        </div>
                    </div>

                    <footer><p>All right reserved. Template by: <a href="https://webthemez.com/admin-template/">WebThemez.com</a></p></footer>
                </div>
                <!-- /. PAGE INNER  -->
            </div>
            <!-- /. PAGE WRAPPER  -->
        </div>
    </div>
        <!-- /. WRAPPER  -->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('layouts.asset.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>